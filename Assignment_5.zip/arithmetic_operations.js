/**
 * College Assignment 1: Arithmetic Operations
 * Name: Ishant Singh
 * Roll No: 102317060
 */

const num1 = parseFloat(prompt("Enter the first number:"));
const num2 = parseFloat(prompt("Enter the second number:"));

if (!isNaN(num1) && !isNaN(num2)) {
    const sum = num1 + num2;
    const difference = num1 - num2;
    const product = num1 * num2;
    let quotient;

    if (num2 !== 0) {
        quotient = num1 / num2;
    } else {
        quotient = "Cannot divide by zero";
    }

    console.log(`--- Arithmetic Operations Results ---`);
    console.log(`Numbers: ${num1}, ${num2}`);
    console.log(`Sum: ${sum}`);
    console.log(`Difference: ${difference}`);
    console.log(`Product: ${product}`);
    console.log(`Quotient: ${quotient}`);

    alert(
        `Results:\n` +
        `Sum: ${sum}\n` +
        `Difference: ${difference}\n` +
        `Product: ${product}\n` +
        `Quotient: ${quotient}`
    );
} else {
    alert("Invalid input. Please enter valid numbers.");
}
