/**
 * College Assignment 2: Array Manipulation
 * Name: Ishant Singh
 * Roll No: 102317060
 */

const numbers = [45, 12, 89, 23, 67];
console.log("Original Array:", numbers);

const largestNumber = Math.max(...numbers);
const smallestNumber = Math.min(...numbers);

console.log(`Largest Number: ${largestNumber}`);
console.log(`Smallest Number: ${smallestNumber}`);

const ascendingOrder = [...numbers].sort((a, b) => a - b);
console.log("Array in Ascending Order:", ascendingOrder);

const descendingOrder = [...numbers].sort((a, b) => b - a);
console.log("Array in Descending Order:", descendingOrder);

alert(
    `Array Operations:\n\n` +
    `Original Array: [${numbers.join(", ")}]\n` +
    `Largest Number: ${largestNumber}\n` +
    `Smallest Number: ${smallestNumber}\n` +
    `Ascending Order: [${ascendingOrder.join(", ")}]\n` +
    `Descending Order: [${descendingOrder.join(", ")}]`
);
