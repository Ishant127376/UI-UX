/**
 * College Assignment 5: Advanced Array Methods
 * Name: Ishant Singh
 * Roll No: 102317060
 */

function processNumbers(numbersArray) {
    console.log("Original Array:", numbersArray);

    const finalSum = numbersArray
        .filter(num => num % 2 === 0)      // Get only the even numbers
        .map(num => num * 2)               // Double each of them
        .reduce((sum, num) => sum + num, 0); // Add them all up

    return finalSum;
}

const initialNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const finalSum = processNumbers(initialNumbers);

console.log(`The final sum is: ${finalSum}`);

alert(
    `Advanced Array Operations:\n\n` +
    `Original Array: [${initialNumbers.join(", ")}]\n` +
    `Final Processed Sum: ${finalSum}`
);
