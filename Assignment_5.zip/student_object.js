/**
 * College Assignment 4: Student Object Operations
 * Name: Ishant Singh
 * Roll No: 102317060
 */

const student = {
    name: "John Doe",
    age: 20,
    grades: {
        math: 85,
        science: 92,
        history: 78
    }
};
console.log("Initial student object:", student);

// Add a new property
student.class = "12th Grade";

// Update an existing property
student.grades.math = 90;

console.log("Updated student object:", student);

// Display all student information
function displayStudentInfo(studentObject) {
    console.log("\n--- Final Student Details ---");
    console.log(`Name: ${studentObject.name}`);
    console.log(`Age: ${studentObject.age}`);
    console.log(`Class: ${studentObject.class}`);
    console.log("Grades:");
    for (const subject in studentObject.grades) {
        console.log(`  - ${subject}: ${studentObject.grades[subject]}`);
    }
}

displayStudentInfo(student);

alert(
    `Final Student Details:\n\n` +
    `Name: ${student.name}\n` +
    `Age: ${student.age}\n` +
    `Class: ${student.class}\n` +
    `Grades:\n` +
    `  - Math: ${student.grades.math}\n` +
    `  - Science: ${student.grades.science}\n` +
    `  - History: ${student.grades.history}`
);
